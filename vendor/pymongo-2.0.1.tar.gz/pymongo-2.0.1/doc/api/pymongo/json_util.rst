:mod:`json_util` -- MOVED
=========================

.. module:: pymongo.json_util

This module has been deprecated in favor of
:mod:`bson.json_util`. Please use that module instead.

.. versionchanged:: 1.9
   Deprecated.
