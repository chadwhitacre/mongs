:mod:`bson` -- MOVED
====================

.. module:: pymongo.bson

This module has been deprecated in favor of :mod:`bson`. Please use
that module instead.

.. versionchanged:: 1.9
   Deprecated.
