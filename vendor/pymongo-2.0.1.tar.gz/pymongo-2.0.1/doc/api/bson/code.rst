:mod:`code` -- Tools for representing JavaScript code
=====================================================

.. automodule:: bson.code
   :synopsis: Tools for representing JavaScript code

   .. autoclass:: Code(code[, scope=None[, **kwargs]])
      :members:
      :show-inheritance:
